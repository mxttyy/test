#### Remember that warehouse scene at the end of Raiders of the Lost Ark?

This /sourceFiles folder is a mess of accumulated cruft built up over the 
years I was tinkering with this project. Some of it might be helpful, some
of it will definitely not.

If you're a beginner trying to make sense of this project, assume that these
files are not needed. Hopefully I'm correct about that.

-Scott